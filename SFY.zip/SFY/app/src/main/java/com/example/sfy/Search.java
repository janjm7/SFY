package com.example.sfy;

import java.util.ArrayList;

public class Search {

    private ArrayList<Image> resultats;

    public Search(ArrayList<Image> resultats) {
        this.resultats = resultats;
    }

    public ArrayList<Image> getResultats() {
        return resultats;
    }

    public void setResultats(ArrayList<Image> resultats) {
        this.resultats = resultats;
    }
}
