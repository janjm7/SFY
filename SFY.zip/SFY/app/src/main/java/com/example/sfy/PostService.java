package com.example.sfy;

import static com.example.sfy.ApiUtilities.KEY;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface PostService {

    @Headers("Authorization: Client-ID " + KEY)
    @GET("/photos")
    Call<List<Image>> getImages(
            @Query("page") int page,
            @Query("per_page") int perPage
    );

    @Headers("Authorization: Client-ID " + KEY)
    @GET("/search/photos")
    Call<Search> searchImage(
            @Query("query") String query
    );
}
