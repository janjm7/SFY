package com.example.sfy;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiUtilities {

    public static final String URL = "https://api.unsplash.com";
    public static final String KEY = "BhVrs-SZ50pbkoewi-glz-hcIVE8aTnjQn8lA9ul3nQ";

    public static Retrofit retrofit = null;

    public static PostService getApiInterface(){

        if (retrofit == null){
            retrofit = new Retrofit.Builder().baseUrl(URL).addConverterFactory(GsonConverterFactory.create()).build();

        }
        return retrofit.create(PostService.class);
    }
}
